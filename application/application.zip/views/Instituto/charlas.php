<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <br>
        <h1>Charlas Abiertas Informativas</h1>
        <div class='alert alert-info'>
                <strong data-toggle='tooltip' title='Instituto Superior del Manejo de la Información'>ISMI</strong> te ofrece la posibilidad de que asistas a Reuniones Informativas Grupales disertadas por el Director de tu Carrera, para que puedas conocer más sobre el Plan de Estudios, modalidad de cursada y salida laboral de la misma. Esta es una oportunidad única para plantear todas las dudas que tenés, y te acerques un poco más a tu futuro.
        </div>
    </body>
</html>
