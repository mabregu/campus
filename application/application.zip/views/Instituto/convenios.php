<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <br>
        <h1>Convenios</h1>
        <div class='alert alert-info'>
                <strong data-toggle='tooltip' title='Instituto Superior del Manejo de la Información'>ISMI</strong>, ha creado lazos interdisciplinarios a través de convenios con distintos organismo públicos y privados, universidades nacionales y extranjeras, referidos a la capacitación, transferencia y explotación de trabajos de investigación con el desarrollo científico y tecnológico. La Dirección de Convenios, dependiente de la Secretaría General, involucra centralmente el análisis, registro y evaluación de los convenios, para su posterior aprobación por el Consejo Superior.
                Se asesora sobre distintos aspectos que tiene que ver con la elaboración tramitación y negociación de convenios profundizando la vinculación con los distintos actores sociales. La Dirección mantiene un Banco de Datos basado en la información de los Convenios aprobados por Consejo Superior de esta Institución con el propósito de poder clasificar, determinar y organizar un sistema útil para brindar una información detallada y precisa acerca de la labor realizada con terceros a lo largo de los años. El mismo se encuentra a disposición en la página WEB de la Dirección y es de muy fácil acceso.
        </div>
    </body>
</html>
